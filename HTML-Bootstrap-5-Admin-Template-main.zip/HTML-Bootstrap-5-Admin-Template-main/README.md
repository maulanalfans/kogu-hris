# HTML-Bootstrap-5-Admin-Template
In this updated tutorial, we’ll create a responsive admin dashboard layout with CSS and a touch of JavaScript. To build it, we’ll borrow some ideas from the  WordPress dashboard, such as its collapsible sidebar menu.
